<?php
/*VerificarUsuario.php: Se recibe por POST el email y la clave, si coinciden con algún registro del archivo JSON
(VerificarExistencia), crear una COOKIE nombrada con el email del usuario que guardará la fecha actual (con
horas, minutos y segundos). Luego ir a ListadoUsuarios.php.
Caso contrario, retornar un JSON que contendrá: éxito(bool) y mensaje(string) indicando lo acontecido.*/
include_once "./clases/usuario.php";
$email=$_POST["email"];
$clave=$_POST["clave"];
$usr= new Usuario($email,$clave);
if(Usuario::VerificarExistencia($usr))
{
    echo "hay uno igual";
    if(!isset($_COOKIE['nombre']))
    {
        setcookie($email,date("H:i:s"));
    }

     header('location:listadoUsuarios.php');
}
else
{
    return json_encode(array('flag' => "false" , 'string'=>"No se hay ningun email igual al ingresado"));
}