<?php
class Usuario
{
    private $_email;
    private $_clave;

    public function __construct($email,$clave)
    {
        $this->_email=$email;
        $this->_clave=$clave;
    }

    public function ToJSON()
    {
        $obj = new Usuario($this->_email,$this->_clave);
        return json_encode($obj,true);
    }

    public function GuardarEnArchivo()
    {
        $flag=false;
        $str="";
        $archivo =fopen("archivos/usuarios.json","a+");

        $cant=fwrite($archivo,$this->ToJSON()."\r\n");

        if($cant>0)
        {
            $flag=true;
            $str="se agrego correctamente";
            return json_encode(array('flag' => $flag , 'string'=>$str));

        }
        else
        {
            $str="No se pudo agregar";
            return json_encode(array('flag' => $flag , 'string'=>$str));
        }
        fclose($archivo);
    }

    public static function TraerTodos()
    {
        $array=array();
        
        $archivo =fopen("archivos/usuarios.json","r");
        while(!feof($archivo))
        {
            $json=fgets($archivo);
            $string=json_decode($json,true);
            $usuario= new Usuario($string->{'email'},$string->{'clave'});
            array_push($array,$usuario);

        }
        fclose($archivo);
        return $array;

    }

    public static function VerificarExistencia($usuario)
    {
        $flag=false;
        $json2=$usuario->ToJSON();
        $str2=json_decode($json2);
        $array=Usuario::TraerTodos();
        
        foreach($array as $usr)
        {
            $json=$usr->ToJSON();
            $str=json_decode($json);
            if($str->{'email'}==$str2->{'email'})
            {
                $flag=true;
            }
        }
        
        return $flag;
    }
}