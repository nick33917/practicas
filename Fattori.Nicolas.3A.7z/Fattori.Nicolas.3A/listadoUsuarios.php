<?php
/*ListadoUsuarios.php: (GET) Se mostrará el listado de todos los empleados en formato JSON.*/
include_once "./clases/usuario.php";
$array=Usuario::TraerTodos();
var_dump($array);