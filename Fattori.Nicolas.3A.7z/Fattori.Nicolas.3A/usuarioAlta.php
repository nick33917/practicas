<?php
include_once "./clases/usuario.php";
$email=$_POST["email"];
$clave=$_POST["clave"];

$usr= new Usuario($email,$clave);
$json=$usr->GuardarEnArchivo();
echo $json;